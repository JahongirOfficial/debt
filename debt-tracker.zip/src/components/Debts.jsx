// Re-export the main debts component
export { QarzdaftarDebts } from './debts/DebtsMain';